# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: petclinic
# Domain name: localhost
# (c)2016 localhost
#
# Backup START time: 01:04:41
# Backup END time: 01:04:41
# Backup Date: 12 Mar 2016
 
drop table if exists `client`; 
CREATE TABLE `client` (
  `clientnumber` int(4) NOT NULL AUTO_INCREMENT,
  `lname` varchar(40) NOT NULL,
  `soundex` char(4) NOT NULL,
  `fname` varchar(25) DEFAULT NULL,
  `prefix` varchar(5) DEFAULT NULL,
  `suffix` varchar(5) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` char(2) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `userid` varchar(10) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_remind` char(1) NOT NULL DEFAULT 'Y',
  `email_followup` char(1) NOT NULL DEFAULT 'Y',
  `email_advice` char(1) NOT NULL DEFAULT 'Y',
  `email_special` char(1) NOT NULL DEFAULT 'Y',
  `status` char(1) NOT NULL DEFAULT 'A',
  `changeid` int(4) NOT NULL,
  PRIMARY KEY (`clientnumber`),
  KEY `lname` (`lname`),
  KEY `soundex` (`soundex`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
insert into `client` (`clientnumber`, `lname`, `soundex`, `fname`, `prefix`, `suffix`, `address`, `address2`, `city`, `state`, `zipcode`, `userid`, `password`, `email`, `email_remind`, `email_followup`, `email_advice`, `email_special`, `status`, `changeid`) values ('1', 'Avila', 'A140', 'Michael', '', '', 'IlvdhNERTP2SeOhtSstcnsFnUWa1k7ICvqBAHoCPZMceGT72drmLx7sIRvx2G3hrO9hTRfse+zz+3696jiQ0qCZ0a2dLvt2+E727QhxPRGktz1sPzs6xQz5ZL3eNMNba|Nk2ddfTICIrN5tuigJ59GHs++mnm8uFhJRjN6XEkP70=', '', 'od9hC6R631AOadSswoP4yb+z+OADhoWFEaUI/0aDftG0SgBEaFjatoteNHC3VOuKhvIs8eMUMTdCey04PfVU9U/XQe6TnF5dY3V1EabXf8Lz0n6IyF2aOHO0qbCKVTvQ|E/Re0yHx1BY4J0x4eeAlxfqfE6T+vSJnl2Ps4/XqhzY=', 'AK', '48310', NULL, NULL, '', 'Y', 'Y', 'Y', 'Y', 'A', '1');
 
drop table if exists `clientpet`; 
CREATE TABLE `clientpet` (
  `petnumber` int(4) NOT NULL,
  `clientnumber` int(4) NOT NULL,
  KEY `petnumber` (`petnumber`),
  KEY `clientnumber` (`clientnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into `clientpet` (`petnumber`, `clientnumber`) values ('3', '1');
insert into `clientpet` (`petnumber`, `clientnumber`) values ('4', '1');
 
drop table if exists `clientphone`; 
CREATE TABLE `clientphone` (
  `clientnumber` int(4) NOT NULL,
  `phonecode` char(1) NOT NULL,
  `phonenumber` char(13) DEFAULT NULL,
  UNIQUE KEY `clientnumber` (`clientnumber`,`phonecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into `clientphone` (`clientnumber`, `phonecode`, `phonenumber`) values ('0', 'H', '586-983-6168');
insert into `clientphone` (`clientnumber`, `phonecode`, `phonenumber`) values ('1', 'H', '586-983-6168');
 
drop table if exists `code_breed`; 
CREATE TABLE `code_breed` (
  `breedcode` char(3) NOT NULL,
  `breeddesc` varchar(40) NOT NULL,
  PRIMARY KEY (`breedcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAA', 'Airedale Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAB', 'Affenpinscher
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAC', 'Afghan Hound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAD', 'Akita
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAE', 'Alaskan Malamute
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAF', 'American English Coonhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAG', 'American Eskimo
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAH', 'American Foxhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAI', 'American Hairless Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAJ', 'American Staffordshire Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAK', 'American Water Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAL', 'Anatolian Shepherd Dog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAM', 'Australian Cattle Dog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAN', 'Australian Shepherd
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CAO', 'Australian Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CB1', 'Griffon Bruxellois
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CB2', 'Bull Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CB3', 'Bulldog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CB4', 'Bullmastiff
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBA', 'Borzoi
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBB', 'Basenji
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBC', 'Basset Hound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBD', 'Beagle
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBE', 'Bearded Collie
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBF', 'Beauceron
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBG', 'Bedlington Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBH', 'Belgian Malinois
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBI', 'Belgian Sheepdog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBJ', 'Belgian Tervuren
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBK', 'Bergamasco Shepherd
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBL', 'Bernese Mountain Dog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBM', 'Bichon FrisÃ©
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBN', 'Black and Tan Coonhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBO', 'Black Russian Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBP', 'Bloodhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBQ', 'Bluetick Coonhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBR', 'order Collie
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBS', 'Border Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBT', 'Borzoi
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBU', 'Boston Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBV', 'Bouvier des Flandres
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBW', 'Boxer
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBX', 'Boykin Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBY', 'Briard
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CBZ', 'Brittany
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCA', 'Clumber Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCB', 'Cairn Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCC', 'Canaan Dog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCD', 'Cane Corso
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCE', 'Cardigan Welsh Corgi
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCF', 'Cavalier King Charles Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCG', 'Cesky Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCH', 'Chesapeake Bay Retriever
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCI', 'Chihuahua
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCJ', 'Chinese Crested Dog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCK', 'Chinese Shar Pei
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCL', 'Chinook
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCM', 'Chow Chow
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCN', 'Clumber Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCO', 'American Cocker Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCP', 'Rough Collie
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCQ', 'Coton de Tulear
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CCR', 'Curly-Coated Retriever
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CDA', 'Dogue de Bordeaux
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CDB', 'Dachshund
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CDC', 'Dalmatian
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CDD', 'Dandie Dinmont Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CDE', 'Doberman Pinscher
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CDF', 'English Cocker Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CEA', 'English Foxhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CEB', 'English Setter
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CEC', 'English Springer Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CED', 'King Charles Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CEE', 'English Toy Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CEF', 'Entlebucher Mountain Dog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CFA', 'Field Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CFB', 'Finnish Lapphund
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CFC', 'Finnish Spitz
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CFD', 'Flat-Coated Retriever
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CFE', 'French Bulldog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CGA', 'Greyhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CGB', 'German Shepherd
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CGC', 'Golden Retriever
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CHA', 'Harrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CHB', 'Havanese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CIA', 'Irish Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CIB', 'Ibizan Hound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CIC', 'Icelandic Sheepdog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CID', 'Irish Red and White Setter
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CIE', 'Irish Setter
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CIF', 'Irish Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CIG', 'Irish Water Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CIH', 'Irish Wolfhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CII', 'Italian Greyhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CJA', 'Japanese Chin
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CKA', 'Keeshond
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CKB', 'Kerry Blue Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CKC', 'Komondor
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CKD', 'Kuvasz
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CLA', 'Labrador Retriever
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CLB', 'Lakeland Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CLC', 'Leonberger
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CLD', 'Lhasa Apso
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CLE', 'LÃ¶wchen
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CMA', 'Miniature Schnauzer
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CMB', 'Maltese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CMC', 'Manchester Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CMD', 'English Mastiff
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CME', 'Miniature Bull Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CMF', 'Miniature Pinscher
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CMG', 'Miniature Schnauzer
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CNA', 'Nova Scotia Duck-Tolling Retriever
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CNB', 'Neapolitan Mastiff
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CNC', 'Newfoundland
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CND', 'Norfolk Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CNE', 'Norwegian Buhund
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CNF', 'Norwegian Elkhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CNG', 'Norwegian Lundehund
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CNH', 'Norwich Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('COA', 'Old English Sheepdog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('COB', 'Otterhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPA', 'Papillon
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPB', 'Parson Russell Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPC', 'Pekingese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPD', 'Pembroke Welsh Corgi
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPE', 'Petit Basset Griffon VendÃ©en
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPF', 'Pharaoh Hound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPG', 'Plott
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPH', 'Pointer
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPI', 'Polish Lowland Sheepdog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPJ', 'Pomeranian
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPK', 'Poodle
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPL', 'Portuguese Podengo
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPM', 'Portuguese Water Dog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPN', 'Pug
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPO', 'Puli
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CPP', 'Pyrenean Shepherd
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CRA', 'Rat Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CRB', 'Redbone Coonhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CRC', 'Rhodesian Ridgeback
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CRD', 'Rottweiler
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CRE', 'Russell Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSA', 'St. Bernard
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSB', 'Saluki
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSC', 'Samoyed
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSD', 'Schipperke
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSE', 'Scottish Deerhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSF', 'Scottish Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSG', 'Sealyham Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSH', 'Shetland Sheepdog
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSI', 'Shiba Inu
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSJ', 'Shih Tzu
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSK', 'Siberian Husky
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSL', 'Australian Silky Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSM', 'Skye Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSN', 'Smooth Fox Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSO', 'Soft-Coated Wheaten Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSP', 'Spinone Italiano]]
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSQ', 'Staffordshire Bull Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSR', 'Standard Schnauzer
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CSS', 'Sussex Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CST', 'Swedish Vallhund
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CTA', 'Tibetan Mastiff
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CTB', 'Tibetan Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CTC', 'Tibetan Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CTD', 'Toy Fox Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CTE', 'Treeing Walker Coonhound
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CVA', 'Hungarian Vizsla
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWA', 'West Highland White Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWB', 'Weimaraner
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWC', 'Welsh Springer Spaniel
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWD', 'Welsh Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWE', 'Whippet
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWF', 'Wire Fox Terrier
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWG', 'Wirehaired Pointing Griffon
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CWH', 'Wirehaired Vizsla
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CXA', 'Xoloitzcuintli
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('CYA', 'Yorkshire Terrier');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAA', 'Abyssinian
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAB', 'Aegean
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAC', 'American Curl
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAD', 'American Bobtail
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAE', 'American Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAF', 'American Wirehair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAG', 'Arabian Mau
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAH', 'Australian Mist
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAI', 'Asian
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FAJ', 'Asian Semi-longhair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBA', 'Balinese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBB', 'Bambino
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBC', 'Bengal
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBD', 'Birman
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBE', 'Bombay
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBF', 'Brazilian Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBG', 'British Semi-longhair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBH', 'British Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBI', 'British Longhair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBJ', 'Burmese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FBK', 'Burmilla
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCA', 'California Spangled
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCB', 'Chantilly-Tiffany
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCC', 'Chartreux
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCD', 'Chausie
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCE', 'Cheetoh
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCF', 'Colorpoint Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCG', 'Cornish Rex
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCH', 'Cymric
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FCI', 'Cyprus
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDA', 'Devon Rex
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDB', 'Domestic Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDC', 'Domestic Medium Hair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDD', 'Domestic Longhair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDE', 'Donskoy
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDF', 'Dragon Li
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDG', 'Dwarf Cat
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDH', 'Egyptian Mau
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FDI', 'European Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FEA', 'Exotic Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FFA', 'FoldEx Cat
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FGA', 'German Rex
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FHA', 'Havana Brown
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FHB', 'Highlander
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FHC', 'Himalayan
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FJA', 'Japanese Bobtail
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FJB', 'Javanese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FKA', 'Kurilian Bobtail
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FKB', 'Khao Manee
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FKC', 'Korat
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FKD', 'Korean Bobtail
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FKE', 'Korn Ja
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FKF', 'Kurilian Bobtail
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FLA', 'LaPerm
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FLB', 'Lykoi
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FMA', 'Maine Coon
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FMB', 'Manx
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FMC', 'Mekong Bobtail
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FMD', 'Minskin
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FME', 'Munchkin
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FNA', 'Nebelung
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FNB', 'Napoleon
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FNC', 'Norwegian Forest Cat
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FOA', 'Ocicat
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FOB', 'Ojos Azules
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FOC', 'Oregon Rex
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FOD', 'Oriental Bicolor
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FOE', 'Oriental Shorthair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FOF', 'Oriental Longhair
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FPA', 'Persian
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FPB', 'Peterbald
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FPC', 'Pixie-bob
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FRA', 'Raas
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FRB', 'Ragamuffin
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FRC', 'Ragdoll
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FRD', 'Russian Blue
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FRE', 'Russian White Black Tabby
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSA', 'Sam Sawet
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSB', 'Savannah
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSC', 'Scottish Fold
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSD', 'Selkirk Rex
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSE', 'Serengeti
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSF', 'Serrade petit
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSG', 'Siamese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSH', 'Siberian
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSI', 'Singapura
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSJ', 'Snowshoe
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSK', 'Sokoke
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSL', 'Sphynx
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FSM', 'Suphalak
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FTA', 'Thai
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FTB', 'Tonkinese
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FTC', 'Toyger
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FTD', 'Turkish Angora
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FTE', 'Turkish Van
');
insert into `code_breed` (`breedcode`, `breeddesc`) values ('FUA', 'Ukrainian Levkoy');
 
drop table if exists `code_phone`; 
CREATE TABLE `code_phone` (
  `phonecode` char(1) NOT NULL,
  `phonedesc` varchar(15) NOT NULL,
  PRIMARY KEY (`phonecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
 
drop table if exists `code_species`; 
CREATE TABLE `code_species` (
  `speciescode` char(1) NOT NULL,
  `speciesdesc` varchar(15) NOT NULL,
  PRIMARY KEY (`speciescode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into `code_species` (`speciescode`, `speciesdesc`) values ('C', 'Canine');
insert into `code_species` (`speciescode`, `speciesdesc`) values ('F', 'Feline');
 
drop table if exists `code_state`; 
CREATE TABLE `code_state` (
  `statecode` char(2) NOT NULL,
  `statedesc` varchar(20) NOT NULL,
  PRIMARY KEY (`statecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into `code_state` (`statecode`, `statedesc`) values ('AK', 'ALASKA');
insert into `code_state` (`statecode`, `statedesc`) values ('AL', 'ALABAMA');
insert into `code_state` (`statecode`, `statedesc`) values ('AR', 'ARKANSAS');
insert into `code_state` (`statecode`, `statedesc`) values ('AZ', 'ARIZONA');
insert into `code_state` (`statecode`, `statedesc`) values ('CA', 'CALIFORNIA');
insert into `code_state` (`statecode`, `statedesc`) values ('CO', 'COLORADO');
insert into `code_state` (`statecode`, `statedesc`) values ('CT', 'CONNECTICUT');
insert into `code_state` (`statecode`, `statedesc`) values ('DC', 'DISTRICT OF COLUMBIA');
insert into `code_state` (`statecode`, `statedesc`) values ('DE', 'DELAWARE');
insert into `code_state` (`statecode`, `statedesc`) values ('FL', 'FLORIDA');
insert into `code_state` (`statecode`, `statedesc`) values ('GA', 'GEORGIA');
insert into `code_state` (`statecode`, `statedesc`) values ('HI', 'HAWAII');
insert into `code_state` (`statecode`, `statedesc`) values ('IA', 'IOWA');
insert into `code_state` (`statecode`, `statedesc`) values ('ID', 'IDAHO');
insert into `code_state` (`statecode`, `statedesc`) values ('IL', 'ILLINOIS');
insert into `code_state` (`statecode`, `statedesc`) values ('IN', 'INDIANA');
insert into `code_state` (`statecode`, `statedesc`) values ('KS', 'KANSAS');
insert into `code_state` (`statecode`, `statedesc`) values ('KY', 'KENTUCKY');
insert into `code_state` (`statecode`, `statedesc`) values ('LA', 'LOUISIANA');
insert into `code_state` (`statecode`, `statedesc`) values ('MA', 'MASSACHUSETTS');
insert into `code_state` (`statecode`, `statedesc`) values ('MD', 'MARYLAND');
insert into `code_state` (`statecode`, `statedesc`) values ('ME', 'MAINE');
insert into `code_state` (`statecode`, `statedesc`) values ('MI', 'MICHIGAN');
insert into `code_state` (`statecode`, `statedesc`) values ('MN', 'MINNESOTA');
insert into `code_state` (`statecode`, `statedesc`) values ('MO', 'MISSOURI');
insert into `code_state` (`statecode`, `statedesc`) values ('MS', 'MISSISSIPPI');
insert into `code_state` (`statecode`, `statedesc`) values ('MT', 'MONTANA');
insert into `code_state` (`statecode`, `statedesc`) values ('NC', 'NORTH CAROLINA');
insert into `code_state` (`statecode`, `statedesc`) values ('ND', 'NORTH DAKOTA');
insert into `code_state` (`statecode`, `statedesc`) values ('NE', 'NEBRASKA');
insert into `code_state` (`statecode`, `statedesc`) values ('NH', 'NEW HAMPSHIRE');
insert into `code_state` (`statecode`, `statedesc`) values ('NJ', 'NEW JERSEY');
insert into `code_state` (`statecode`, `statedesc`) values ('NM', 'NEW MEXICO');
insert into `code_state` (`statecode`, `statedesc`) values ('NV', 'NEVADA');
insert into `code_state` (`statecode`, `statedesc`) values ('NY', 'NEW YORK');
insert into `code_state` (`statecode`, `statedesc`) values ('OH', 'OHIO');
insert into `code_state` (`statecode`, `statedesc`) values ('OK', 'OKLAHOMA');
insert into `code_state` (`statecode`, `statedesc`) values ('OR', 'OREGON');
insert into `code_state` (`statecode`, `statedesc`) values ('PA', 'PENNSYLVANIA');
insert into `code_state` (`statecode`, `statedesc`) values ('PR', 'PUERTO RICO');
insert into `code_state` (`statecode`, `statedesc`) values ('RI', 'RHODE ISLAND');
insert into `code_state` (`statecode`, `statedesc`) values ('SC', 'SOUTH CAROLINA');
insert into `code_state` (`statecode`, `statedesc`) values ('SD', 'SOUTH DAKOTA');
insert into `code_state` (`statecode`, `statedesc`) values ('TN', 'TENNESSEE');
insert into `code_state` (`statecode`, `statedesc`) values ('TX', 'TEXAS');
insert into `code_state` (`statecode`, `statedesc`) values ('UT', 'UTAH');
insert into `code_state` (`statecode`, `statedesc`) values ('VA', 'VIRGINIA');
insert into `code_state` (`statecode`, `statedesc`) values ('VT', 'VERMONT');
insert into `code_state` (`statecode`, `statedesc`) values ('WA', 'WASHINGTON');
insert into `code_state` (`statecode`, `statedesc`) values ('WI', 'WISCONSIN');
insert into `code_state` (`statecode`, `statedesc`) values ('WV', 'WEST VIRGINIA');
insert into `code_state` (`statecode`, `statedesc`) values ('WY', 'WYOMING');
 
drop table if exists `pet`; 
CREATE TABLE `pet` (
  `petnumber` int(4) NOT NULL AUTO_INCREMENT,
  `petname` varchar(15) NOT NULL,
  `petdob` char(8) NOT NULL,
  `petspecies` char(1) NOT NULL,
  `petbreed` char(2) NOT NULL,
  `petgender` char(1) NOT NULL,
  `petfixed` char(1) NOT NULL,
  `petcolor` varchar(20) NOT NULL,
  `petdesc` varchar(50) NOT NULL,
  `license` varchar(15) DEFAULT NULL,
  `microchip` varchar(18) DEFAULT NULL,
  `rabiestag` varchar(10) DEFAULT NULL,
  `tattoonumber` varchar(10) DEFAULT NULL,
  `picture` char(1) NOT NULL DEFAULT 'N',
  `status` char(1) NOT NULL DEFAULT 'A',
  `changeid` int(4) NOT NULL,
  PRIMARY KEY (`petnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1457741081');
 
drop table if exists `visit`; 
CREATE TABLE `visit` (
  `visitnumber` int(4) NOT NULL AUTO_INCREMENT,
  `visitdate` int(8) NOT NULL,
  `petnumber` int(4) NOT NULL,
  `temp` decimal(4,1) DEFAULT NULL,
  `weight` decimal(4,1) DEFAULT NULL,
  `pulse` int(2) DEFAULT NULL,
  `respiration` int(3) DEFAULT NULL,
  `panting` char(1) DEFAULT NULL,
  `caprefill` int(2) DEFAULT NULL,
  `mucous` varchar(20) DEFAULT NULL,
  `hydration` varchar(20) DEFAULT NULL,
  `clinicalstay` char(1) DEFAULT NULL,
  `clinicaldischarge` char(1) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'A',
  `changeid` int(4) NOT NULL,
  PRIMARY KEY (`visitnumber`),
  KEY `changeid` (`changeid`),
  KEY `petnumber` (`petnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
